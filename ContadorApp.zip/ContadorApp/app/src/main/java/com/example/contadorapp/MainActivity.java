package com.example.contadorapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private final String KEY_CONT = "kcont";
    private EditText CampoConteo;
private Button BotonContar;
private Button BotonLimpiar;
//private TextView ContTextView;
private int conteo=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        CampoConteo = findViewById(R.id.campo_conteo);
        BotonContar=findViewById(R.id.boton_contar);
        BotonLimpiar=findViewById(R.id.boton_limpiar);
        BotonContar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                conteo++;
                CampoConteo.setText(Integer.toString(conteo));
            }
        });
        BotonLimpiar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                CampoConteo.setText(" ");
                conteo=0;
            }
        });
        if(savedInstanceState != null){
            conteo = savedInstanceState.getInt(KEY_CONT);
            CampoConteo.setText(Integer.toString(conteo));
        }else{
            conteo = 0;
            CampoConteo.setText("  ");
        }

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(KEY_CONT, conteo);
    }
}
